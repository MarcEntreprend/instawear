// src/admin/ProductQuickViewModal.tsx

import React from "react";
import { X, Star, ShieldCheck, Tag } from "lucide-react";
import type { AdminProduct } from "./adminTypes";
import { useCurrencySymbol } from "../hooks/useCurrencySymbol";
import { PLACEHOLDER_IMG } from "../constants/assets";

interface ProductQuickViewModalProps {
  product: AdminProduct | null;
  onClose: () => void;
}

export default function ProductQuickViewModal({
  product,
  onClose,
}: ProductQuickViewModalProps) {
  if (!product) return null;

  // state pour suivre l'image active, et rendre les miniatures cliquables.
  const [activeImage, setActiveImage] = React.useState(0);

  const hasVariants = product.variants && product.variants.length > 0;
  const dispColors = hasVariants ? product.variants!.map((v) => v.color) : product.colors;
  const dispColorNames = hasVariants ? product.variants!.map((v) => v.color_name) : product.colorNames;

  const [pickedColorIdx, setPickedColorIdx] = React.useState<number | null>(
    dispColors.length > 0 ? 0 : null,
  );

  const currencySymbol = useCurrencySymbol();

  const variantImages: string[] = hasVariants
    ? product.variants!.map((v) => v.image || "")
    : product.colorImages || [];

  const filteredColorImages = variantImages.filter(
    (url) => url && url.trim().length > 0,
  );

  const hasColorImages = filteredColorImages.length > 0;

  const allImages = [product.image, ...(product.gallery || [])].filter(
    (url) => url && url !== PLACEHOLDER_IMG,
  );

  const displayImage =
    pickedColorIdx !== null &&
    filteredColorImages[pickedColorIdx]
      ? filteredColorImages[pickedColorIdx]
      : allImages[activeImage] || PLACEHOLDER_IMG;

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 300,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(26,20,10,0.5)",
        backdropFilter: "blur(4px)",
      }}
      onClick={onClose}
    >
      <div
        style={{
          background: "var(--color-surface)",
          border: "1px solid var(--color-border)",
          borderRadius: 20,
          width: "90%",
          maxWidth: 800,
          maxHeight: "85vh",
          overflowY: "auto",
          boxShadow: "var(--shadow-xl)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "16px 22px",
            borderBottom: "1px solid var(--color-border)",
          }}
        >
          <h3
            style={{ fontWeight: 700, fontSize: 16, color: "var(--color-ink)" }}
          >
            Aperçu produit Admin
          </h3>
          <button
            onClick={onClose}
            style={{
              background: "var(--color-surface2)",
              border: "1px solid var(--color-border)",
              borderRadius: 8,
              padding: "4px 8px",
              cursor: "pointer",
              color: "var(--color-ink2)",
            }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Contenu */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 20,
            padding: 20,
          }}
        >
          {/* Colonne gauche - Image */}
          <div>
            <div
              style={{
                aspectRatio: "4/5",
                borderRadius: 14,
                overflow: "hidden",
                background: "var(--color-surface2)",
                border: "1px solid var(--color-border)",
                position: "relative",
              }}
            >
              <img
                src={displayImage}
                alt={product.title}
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
              <div
                style={{
                  position: "absolute",
                  top: 10,
                  left: 10,
                  display: "flex",
                  flexDirection: "column",
                  gap: 4,
                }}
              >
                {product.isBestSeller && (
                  <span
                    className="badge text-gray-900"
                    style={{ background: "var(--color-gold)" }}
                  >
                    ★ Best seller
                  </span>
                )}
                {product.isLimitedTime && (
                  <span
                    className="badge text-gray-900"
                    style={{ background: "#EF4444" }}
                  >
                    Offre limitée
                  </span>
                )}
                {!product.isActive && (
                  <span
                    className="badge"
                    style={{
                      background: "var(--color-surface)",
                      color: "var(--color-ink3)",
                      border: "1px solid var(--color-border)",
                    }}
                  >
                    Inactif
                  </span>
                )}
              </div>
            </div>
            {/* Galerie complète (image principale + images additionnelles) */}
            {!(
              pickedColorIdx !== null && filteredColorImages[pickedColorIdx]
            ) &&
              (() => {
                if (allImages.length <= 1) return null;

                return (
                  <div
                    style={{
                      display: "grid",

                      gridTemplateColumns:
                        "repeat(auto-fill, minmax(50px, 1fr))",

                      gap: 6,

                      marginTop: 10,
                    }}
                  >
                    {allImages.map((url, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setActiveImage(idx);

                          setPickedColorIdx(null);
                        }}
                        style={{
                          width: "100%",

                          aspectRatio: "1 / 1",

                          borderRadius: 8,

                          overflow: "hidden",

                          border:
                            activeImage === idx
                              ? "2px solid var(--color-accent)"
                              : "1px solid var(--color-border)",

                          padding: 0,

                          cursor: "pointer",

                          background: "none",
                        }}
                      >
                        <img
                          src={url}
                          alt=""
                          style={{
                            width: "100%",

                            height: "100%",

                            objectFit: "cover",
                          }}
                        />
                      </button>
                    ))}
                  </div>
                );
              })()}

            {/* Color dots selector */}

              {dispColors.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                    Color
                  </label>
                  <div className="flex gap-1.5 flex-wrap">
                    {dispColors.map((c, idx) => (
                      <button
                        key={idx}
                        onClick={() => setPickedColorIdx(idx)}
                        className={`rounded-full w-7 h-7 border-2 transition ${pickedColorIdx === idx ? "border-cyan-400" : "border-gray-200"}`}
                        style={{ backgroundColor: c }}
                        title={dispColorNames?.[idx] || c}
                      />
                    ))}
                  </div>
                </div>
              )}
          </div>

          {/* Colonne droite - Infos */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <span
                style={{
                  fontSize: 11,
                  color: "var(--color-ink4)",
                  textTransform: "uppercase",
                  fontWeight: 700,
                }}
              >
                {product.brand}
              </span>
              <h3
                style={{
                  fontSize: 20,
                  fontWeight: 700,
                  color: "var(--color-ink)",
                  marginTop: 4,
                }}
              >
                {product.title}
              </h3>
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                fontSize: 12,
                color: "var(--color-ink3)",
              }}
            >
              <Star size={12} fill="#f59e0b" stroke="#f59e0b" />
              <span style={{ fontWeight: 600 }}>
                {product.ratings.score.toFixed(1)}
              </span>
              <span>({product.ratings.count} avis)</span>
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "baseline",
                gap: 10,
                padding: "12px 14px",
                borderRadius: 12,
                background: "var(--color-surface2)",
              }}
            >
              <span
                style={{
                  fontSize: 24,
                  fontWeight: 800,
                  color: "var(--color-ink)",
                }}
              >
                {product.price.toFixed(2)} {currencySymbol}
              </span>
              {product.originalPrice && (
                <span
                  style={{
                    fontSize: 14,
                    textDecoration: "line-through",
                    color: "var(--color-ink4)",
                  }}
                >
                  {product.originalPrice.toFixed(2)} {currencySymbol}
                </span>
              )}
              {discount > 0 && (
                <span
                  className="badge text-gray-900"
                  style={{ background: "var(--color-accent)" }}
                >
                  -{discount}%
                </span>
              )}
            </div>
            <div
              style={{
                display: "flex",
                gap: 16,
                fontSize: 12,
                color: "var(--color-ink3)",
              }}
            >
              <span>
                Stock :{" "}
                <strong
                  style={{
                    color: product.inStock ? "var(--color-success)" : "#ef4444",
                  }}
                >
                  {product.inStock
                    ? `${product.stockQuantity ?? "—"} unités`
                    : "Sur commande"}
                </strong>
              </span>
              <span>
                Visibilité :{" "}
                <strong
                  style={{
                    color: product.isActive
                      ? "var(--color-success)"
                      : "var(--color-ink4)",
                  }}
                >
                  {product.isActive ? "Actif" : "Inactif"}
                </strong>
              </span>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <span
                className="badge"
                style={{
                  background: "var(--color-surface2)",
                  color: "var(--color-ink3)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <Tag size={10} /> {product.category}
              </span>
              <span
                className="badge"
                style={{
                  background: "var(--color-surface2)",
                  color: "var(--color-ink3)",
                  border: "1px solid var(--color-border)",
                }}
              >
                {product.eventType}
              </span>
              <span
                className="badge"
                style={{
                  background: "var(--color-surface2)",
                  color: "var(--color-ink3)",
                  border: "1px solid var(--color-border)",
                }}
              >
                {product.style}
              </span>
            </div>
            {/* Description courte */}
            {product.description && (
              <p
                style={{
                  fontSize: 12,
                  color: "var(--color-ink2)",
                  lineHeight: 1.6,
                  fontStyle: "italic",
                }}
              >
                {product.description}
              </p>
            )}
            {/* Fiche technique (description longue) */}
            {product.fullDescription && (
              <div
                style={{
                  fontSize: 12,
                  color: "var(--color-ink)",
                  lineHeight: 1.6,
                  whiteSpace: "pre-line",
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: "var(--color-surface2)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <p
                  style={{
                    fontWeight: 700,
                    fontSize: 11,
                    color: "var(--color-ink3)",
                    textTransform: "uppercase",
                    marginBottom: 6,
                  }}
                >
                  Fiche technique
                </p>
                {product.fullDescription}
              </div>
            )}

            {/* Printful info */}
            {product.externalProductId && (
              <div
                style={{
                  fontSize: 12,
                  color: "var(--color-ink3)",
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: "var(--color-surface2)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <p
                  style={{
                    fontWeight: 700,
                    fontSize: 11,
                    color: "var(--color-ink3)",
                    textTransform: "uppercase",
                    marginBottom: 6,
                  }}
                >
                  📦 Printful
                </p>
                <p>Product ID : {product.externalProductId}</p>
                <p>Variant ID : {product.externalVariantId || "—"}</p>
                {product.printfulPrice != null && (
                  <p>
                    Prix Printful : {product.printfulPrice.toFixed(2)}{" "}
                    {product.printfulCurrency || "$"}
                  </p>
                )}
                <p>
                  Dernière synchro :{" "}
                  {product.lastExternalSync
                    ? new Date(product.lastExternalSync).toLocaleString("fr-FR")
                    : "—"}
                </p>
              </div>
            )}

            {/* Printful Pricing */}
            {product.printfulPrice != null && product.printfulPrice > 0 && (
              <div
                style={{
                  fontSize: 12,
                  color: "var(--color-ink3)",
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: "var(--color-surface2)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <p
                  style={{
                    fontWeight: 700,
                    fontSize: 11,
                    color: "var(--color-ink3)",
                    textTransform: "uppercase",
                    marginBottom: 6,
                  }}
                >
                  💰 Printful Pricing
                </p>
                <p>
                  Printful price : {product.printfulPrice.toFixed(2)}{" "}
                  {product.printfulCurrency || "BRL"}
                </p>
                <p>
                  Printful shipping price :{" "}
                  {(product.shippingEstimate ?? 0).toFixed(2)}{" "}
                  {product.printfulCurrency || "BRL"}
                </p>
                {/* Calcul de la marge en % et en valeur */}
                {(() => {
                  const cost = product.printfulPrice;
                  const shipping = product.shippingEstimate ?? 0;
                  const retail = product.price;
                  const marginPercent =
                    cost + shipping > 0
                      ? (retail / (cost + shipping) - 1) * 100
                      : 0;
                  const revenue = retail - (cost + shipping);
                  return (
                    <>
                      <p>
                        Marge souhaitée : {marginPercent.toFixed(0)}% (
                        {revenue.toFixed(2)} {product.printfulCurrency || "BRL"}
                        )
                      </p>
                      <p>
                        Revenue : {revenue.toFixed(2)}{" "}
                        {product.printfulCurrency || "BRL"}
                      </p>
                    </>
                  );
                })()}
              </div>
            )}

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                fontSize: 11,
                color: "var(--color-ink4)",
                padding: "10px 12px",
                borderRadius: 10,
                background: "var(--color-surface2)",
              }}
            >
              <ShieldCheck size={14} style={{ color: "var(--color-accent)" }} />{" "}
              Impression certifiée OEKO-TEX®
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
