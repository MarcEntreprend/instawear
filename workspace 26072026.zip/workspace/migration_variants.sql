-- Migration: add `variants` JSONB column to `products`
-- Replaces parallel columns: colors[], color_names[], sizes[], color_images[], size_surcharge{}

-- 1. Add the column (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'variants'
  ) THEN
    ALTER TABLE products ADD COLUMN variants jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- 2. Migrate existing data from parallel columns into variants
-- Each existing product gets a variants array built from its parallel columns
UPDATE products
SET variants = (
  SELECT jsonb_agg(
    jsonb_build_object(
      'color',        colors.col,
      'color_name',   colors.cname,
      'image',        colors.cimg,
      'sizes',        (
        SELECT jsonb_object_agg(sz, jsonb_build_object('price', COALESCE(
          (products.price + COALESCE((products.size_surcharge ->> sz)::numeric, 0)),
          products.price
        )))
        FROM unnest(products.sizes) AS sz
      )
    )
    ORDER BY colors.idx
  )
  FROM (
    SELECT
      row_number() OVER () - 1 AS idx,
      col[1] AS col,
      col[2] AS cname,
      col[3] AS cimg
    FROM (
      SELECT ARRAY[
        COALESCE(colors_arr[i], ''),
        COALESCE(color_names_arr[i], ''),
        COALESCE(color_images_arr[i], '')
      ] AS col
      FROM (
        SELECT
          products.colors AS colors_arr,
          COALESCE(products.color_names, ARRAY[]::text[]) AS color_names_arr,
          COALESCE(products.color_images, ARRAY[]::text[]) AS color_images_arr,
          generate_series(1, array_length(products.colors, 1)) AS i
      ) sub1
    ) sub2
    WHERE col[1] IS NOT NULL AND col[1] <> ''
  ) colors
)
WHERE variants = '[]'::jsonb OR variants IS NULL;

-- 3. Index for querying variants (e.g. finding products by color)
CREATE INDEX IF NOT EXISTS idx_products_variants_gin ON products USING gin (variants);
